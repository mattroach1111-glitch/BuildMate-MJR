import { FortnightTimesheet } from "@/components/fortnight-timesheet";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import PageLayout from "@/components/page-layout";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function FortnightTimesheetView() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [employeeId, setEmployeeId] = useState<string>("");
  const [isAdminView, setIsAdminView] = useState<boolean>(false);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const employee = urlParams.get('employee');
    const admin = urlParams.get('admin');
    
    if (employee) {
      setEmployeeId(employee);
    }
    
    if (admin === 'true') {
      setIsAdminView(true);
    }
  }, []);

  const handleBackNavigation = () => {
    if ((user as any)?.role === "admin") {
      setLocation("/admin");
    } else {
      // For staff, go back to staff dashboard
      setLocation("/");
    }
  };

  const getTitle = () => {
    if (isAdminView && employeeId) {
      return "Staff Timesheet Management";
    }
    return "Fortnight Timesheet";
  };

  const getSubtitle = () => {
    if (isAdminView && employeeId) {
      return "Managing timesheet entries and approvals";
    }
    return "Track your hours and submit timesheet entries";
  };

  // For staff users, show timesheet with back navigation to staff dashboard
  if ((user as any)?.role !== "admin") {
    return (
      <PageLayout 
        title="Fortnight Timesheet"
        subtitle="Track your hours and submit timesheet entries"
      >
        <div className="space-y-6">
          {/* Back Button for Staff */}
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={handleBackNavigation}
              className="flex items-center gap-2"
              data-testid="button-back-to-staff-dashboard"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </div>

          {/* Staff Timesheet */}
          <div className="max-w-6xl mx-auto">
            <FortnightTimesheet 
              selectedEmployeeId=""
              isAdminView={false}
            />
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout 
      title={getTitle()}
      subtitle={getSubtitle()}
    >
      <div className="space-y-6">
        {/* Navigation Bar - Only show for admin viewing staff timesheets */}
        {isAdminView && employeeId && (
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={handleBackNavigation}
              className="flex items-center gap-2"
              data-testid="button-back-to-dashboard"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Admin
            </Button>
          </div>
        )}

        {/* Admin users get full interface */}
        <div className="max-w-6xl mx-auto">
          <FortnightTimesheet 
            selectedEmployeeId={employeeId}
            isAdminView={isAdminView}
          />
        </div>
      </div>
    </PageLayout>
  );
}