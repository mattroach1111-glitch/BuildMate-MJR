import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Plus, Edit3, Trash2, DollarSign, Clock, User, ArrowLeft, Save, X, Calculator, Download } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'wouter';
import jsPDF from 'jspdf';

interface StaffMember {
  id: string;
  name: string;
  bankedHours: string;
  rdoHours: string;
  hourlyRate: string;
  toolCostOwed: string;
  notes: StaffNote[];
  createdAt?: Date;
  updatedAt?: Date;
}

interface StaffNote {
  id: string;
  type: 'banked_hours' | 'tool_cost' | 'rdo_hours' | 'general';
  description: string;
  amount: string;
  date: string;
  staffMemberId: string;
  createdAt?: Date;
}

interface NoteFormData {
  type: 'banked_hours' | 'tool_cost' | 'rdo_hours' | 'general';
  description: string;
  amount: string;
}

export default function StaffNotesClean() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  
  // Show loading while checking authentication
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  // Show login message if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Authentication Required</h2>
          <p className="text-gray-600 mb-6">Please log in to access the staff notes system.</p>
          <button
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }
  
  // Show admin required message if not admin
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Admin Access Required</h2>
          <p className="text-gray-600">You need admin privileges to access the staff notes system.</p>
        </div>
      </div>
    );
  }

  const { data: staff = [], isLoading, error } = useQuery<StaffMember[]>({
    queryKey: ['/api/staff-notes'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/staff-notes', {
          credentials: 'include',
        });
        
        if (response.status === 401) {
          // Handle unauthorized access - show login message instead of redirecting
          throw new Error('Please log in to access staff notes');
        }
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Failed to fetch staff notes (${response.status}): ${errorText || response.statusText}`);
        }
        
        return response.json();
      } catch (fetchError) {
        if (fetchError instanceof Error) {
          throw fetchError;
        }
        throw new Error('Network error: Unable to connect to server');
      }
    },
    retry: false,
  });

  // Mutations for staff members
  const createStaffMutation = useMutation({
    mutationFn: async (staffData: { id: string; name: string; hourlyRate: string }) => {
      const response = await apiRequest('POST', '/api/staff-notes/members', staffData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-notes'] });
      setIsAddStaffOpen(false);
      setNewStaffName('');
      setNewStaffRate('');
      showToast('Staff member added successfully');
    },
  });

  const updateStaffMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<StaffMember> }) => {
      const response = await apiRequest('PUT', `/api/staff-notes/members/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-notes'] });
      setEditingStaff(null);
      setEditStaffRate('');
      showToast('Staff member updated successfully');
    },
  });

  const deleteStaffMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/staff-notes/members/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-notes'] });
      showToast('Staff member deleted successfully');
    },
  });

  // Mutations for notes
  const createNoteMutation = useMutation({
    mutationFn: async ({ memberId, noteData }: { memberId: string; noteData: any }) => {
      const response = await apiRequest('POST', `/api/staff-notes/members/${memberId}/notes`, noteData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-notes'] });
      setNoteForm({ type: 'general', description: '', amount: '' });
      setIsAddNoteOpen(false);
      setEditingNote(null);
      showToast('Note added successfully');
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<StaffNote> }) => {
      const response = await apiRequest('PUT', `/api/staff-notes/notes/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-notes'] });
      setEditingNote(null);
      setNoteForm({ type: 'general', description: '', amount: '' });
      setIsAddNoteOpen(false);
      showToast('Note updated successfully');
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/staff-notes/notes/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-notes'] });
      showToast('Note deleted successfully');
    },
  });

  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isAddStaffOpen, setIsAddStaffOpen] = useState(false);
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<StaffNote | null>(null);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRate, setNewStaffRate] = useState('');
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [editStaffRate, setEditStaffRate] = useState('');
  const [noteForm, setNoteForm] = useState<NoteFormData>({
    type: 'general',
    description: '',
    amount: '',
  });
  const [toastMessage, setToastMessage] = useState<string>('');

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="text-lg font-medium text-gray-900 dark:text-gray-100">Loading staff notes...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="text-lg font-medium text-red-600">Error loading staff notes</div>
          <div className="text-sm text-gray-600 dark:text-gray-400 mt-2">{(error as Error).message}</div>
        </div>
      </div>
    );
  }

  // Simple toast replacement
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const addStaffMember = () => {
    if (!newStaffName.trim()) {
      showToast('Please enter a staff member name');
      return;
    }

    const hourlyRate = newStaffRate || '0';
    
    createStaffMutation.mutate({
      id: Date.now().toString(),
      name: newStaffName.trim(),
      hourlyRate,
    });
  };

  const deleteStaffMember = (id: string) => {
    const member = staff.find(s => s.id === id);
    if (confirm(`Are you sure you want to remove ${member?.name} and all their notes?`)) {
      deleteStaffMutation.mutate(id);
      if (selectedStaff?.id === id) {
        setSelectedStaff(null);
      }
    }
  };

  const startEditStaffRate = (member: StaffMember) => {
    setEditingStaff(member);
    setEditStaffRate(member.hourlyRate.toString());
  };

  const updateStaffRate = () => {
    if (!editingStaff) return;
    
    const newRate = editStaffRate || '0';
    
    updateStaffMutation.mutate({
      id: editingStaff.id,
      data: { hourlyRate: newRate }
    });

    // Update selected staff local state if it's the same member
    if (selectedStaff?.id === editingStaff.id) {
      setSelectedStaff(prev => prev ? { ...prev, hourlyRate: newRate } : null);
    }
  };

  const generateIndividualPDF = (staffMember: StaffMember) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    const margin = 20;
    let yPosition = 30;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text(`Staff Notes - ${staffMember.name}`, pageWidth / 2, yPosition, { align: 'center' });
    
    // Date
    yPosition += 10;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated: ${format(new Date(), 'PPP')}`, pageWidth / 2, yPosition, { align: 'center' });
    
    yPosition += 20;

    // Staff member header
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(`${staffMember.name}`, margin, yPosition);
    yPosition += 8;

    // Summary info
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const bankedHours = parseFloat(staffMember.bankedHours) || 0;
    const hourlyRate = parseFloat(staffMember.hourlyRate) || 0;
    const toolCostOwed = parseFloat(staffMember.toolCostOwed) || 0;
    const summaryText = `Banked Hours: ${bankedHours} | RDO Hours: ${staffMember.rdoHours} | Rate: $${hourlyRate}/hr | Value: $${(bankedHours * hourlyRate).toFixed(2)} | Tools Owed: $${toolCostOwed.toFixed(2)}`;
    doc.text(summaryText, margin, yPosition);
    yPosition += 15;

    if (staffMember.notes.length === 0) {
      doc.setFont('helvetica', 'italic');
      doc.text('No notes recorded', margin + 5, yPosition);
      yPosition += 10;
    } else {
      // Notes header
      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.text('Notes:', margin + 5, yPosition);
      yPosition += 8;

      // Sort notes by date (newest first)
      const sortedNotes = [...staffMember.notes].sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );

      sortedNotes.forEach((note, noteIndex) => {
        // Check if we need a new page for notes
        if (yPosition > 270) {
          doc.addPage();
          yPosition = 30;
        }

        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        
        const typeText = note.type === 'banked_hours' ? 'Banked Hours' :
                        note.type === 'rdo_hours' ? 'RDO Hours' :
                        note.type === 'tool_cost' ? 'Tool Cost' : 'General';
        
        const amount = parseFloat(note.amount) || 0;
        const amountText = note.type === 'banked_hours' || note.type === 'rdo_hours' 
          ? `${amount > 0 ? '+' : ''}${amount} hrs`
          : `${amount > 0 ? '+' : ''}$${Math.abs(amount).toFixed(2)}`;

        // Note line
        const noteText = `${format(new Date(note.date), 'MMM dd, yyyy')} | ${typeText} | ${amountText} | ${note.description}`;
        
        // Split long text if needed
        const textLines = doc.splitTextToSize(noteText, pageWidth - margin * 2 - 10);
        textLines.forEach((line: string) => {
          doc.text(line, margin + 10, yPosition);
          yPosition += 5;
        });
        yPosition += 2;
      });
    }

    // Footer
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, doc.internal.pageSize.height - 10, { align: 'center' });
      doc.text(`BuildFlow Pro - ${staffMember.name} Notes`, margin, doc.internal.pageSize.height - 10);
    }

    // Save the PDF
    const fileName = `staff-notes-${staffMember.name.replace(/\s+/g, '-').toLowerCase()}-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
    doc.save(fileName);
    showToast(`PDF generated for ${staffMember.name}`);
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    const margin = 20;
    let yPosition = 30;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Staff Notes Report', pageWidth / 2, yPosition, { align: 'center' });
    
    // Date
    yPosition += 10;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated: ${format(new Date(), 'PPP')}`, pageWidth / 2, yPosition, { align: 'center' });
    
    yPosition += 20;

    staff.forEach((member, memberIndex) => {
      // Check if we need a new page
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 30;
      }

      // Staff member header
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(`${member.name}`, margin, yPosition);
      yPosition += 8;

      // Summary info
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      const bankedHours = parseFloat(member.bankedHours) || 0;
      const hourlyRate = parseFloat(member.hourlyRate) || 0;
      const toolCostOwed = parseFloat(member.toolCostOwed) || 0;
      const summaryText = `Banked Hours: ${bankedHours} | RDO Hours: ${member.rdoHours} | Rate: $${hourlyRate}/hr | Value: $${(bankedHours * hourlyRate).toFixed(2)} | Tools Owed: $${toolCostOwed.toFixed(2)}`;
      doc.text(summaryText, margin, yPosition);
      yPosition += 15;

      if (member.notes.length === 0) {
        doc.setFont('helvetica', 'italic');
        doc.text('No notes recorded', margin + 5, yPosition);
        yPosition += 10;
      } else {
        // Notes header
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text('Notes:', margin + 5, yPosition);
        yPosition += 8;

        // Sort notes by date (newest first)
        const sortedNotes = [...member.notes].sort((a, b) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        );

        sortedNotes.forEach((note, noteIndex) => {
          // Check if we need a new page for notes
          if (yPosition > 270) {
            doc.addPage();
            yPosition = 30;
          }

          doc.setFontSize(9);
          doc.setFont('helvetica', 'normal');
          
          const typeText = note.type === 'banked_hours' ? 'Banked Hours' :
                          note.type === 'rdo_hours' ? 'RDO Hours' :
                          note.type === 'tool_cost' ? 'Tool Cost' : 'General';
          
          const amount = parseFloat(note.amount) || 0;
          const amountText = note.type === 'banked_hours' || note.type === 'rdo_hours' 
            ? `${amount > 0 ? '+' : ''}${amount} hrs`
            : `${amount > 0 ? '+' : ''}$${Math.abs(amount).toFixed(2)}`;

          // Note line
          const noteText = `${format(new Date(note.date), 'MMM dd, yyyy')} | ${typeText} | ${amountText} | ${note.description}`;
          
          // Split long text if needed
          const textLines = doc.splitTextToSize(noteText, pageWidth - margin * 2 - 10);
          textLines.forEach((line: string) => {
            doc.text(line, margin + 10, yPosition);
            yPosition += 5;
          });
          yPosition += 2;
        });
      }

      yPosition += 10;

      // Add separator line if not last member
      if (memberIndex < staff.length - 1) {
        doc.setDrawColor(200, 200, 200);
        doc.line(margin, yPosition, pageWidth - margin, yPosition);
        yPosition += 15;
      }
    });

    // Footer on last page
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, doc.internal.pageSize.height - 10, { align: 'center' });
      doc.text('BuildFlow Pro - Staff Notes Report', margin, doc.internal.pageSize.height - 10);
    }

    // Save the PDF
    const fileName = `staff-notes-report-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
    doc.save(fileName);
    showToast('PDF report generated successfully');
  };

  const addNote = () => {
    if (!selectedStaff || !noteForm.description.trim()) {
      showToast('Please fill in all required fields');
      return;
    }

    const noteData = {
      id: Date.now().toString(),
      type: noteForm.type,
      description: noteForm.description.trim(),
      amount: noteForm.amount || '0',
      date: new Date().toISOString(),
    };

    createNoteMutation.mutate({
      memberId: selectedStaff.id,
      noteData
    });
  };

  const updateNote = () => {
    if (!selectedStaff || !editingNote || !noteForm.description.trim()) {
      return;
    }

    const updatedData = {
      description: noteForm.description.trim(),
      amount: noteForm.amount || '0',
    };

    updateNoteMutation.mutate({
      id: editingNote.id,
      data: updatedData
    });
  };

  const deleteNote = (noteId: string) => {
    if (!selectedStaff) return;

    if (confirm('Are you sure you want to delete this note?')) {
      deleteNoteMutation.mutate(noteId);
    }
  };

  const startEditNote = (note: StaffNote) => {
    setEditingNote(note);
    setNoteForm({
      type: note.type,
      description: note.description,
      amount: note.amount.toString(),
    });
    setIsAddNoteOpen(true);
  };

  const resetNoteForm = () => {
    setEditingNote(null);
    setNoteForm({ type: 'general', description: '', amount: '' });
    setIsAddNoteOpen(false);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'banked_hours': return <Clock className="h-4 w-4" />;
      case 'rdo_hours': return <Clock className="h-4 w-4" />;
      case 'tool_cost': return <DollarSign className="h-4 w-4" />;
      default: return <User className="h-4 w-4" />;
    }
  };

  const getTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'banked_hours': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'rdo_hours': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'tool_cost': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  const formatTypeName = (type: string) => {
    switch (type) {
      case 'banked_hours': return 'Banked Hours';
      case 'rdo_hours': return 'RDO Hours';
      case 'tool_cost': return 'Tool Cost';
      default: return 'General';
    }
  };

  if (!selectedStaff) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        {/* Toast notification */}
        {toastMessage && (
          <div className="fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded-md shadow-lg z-50">
            {toastMessage}
          </div>
        )}

        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 sm:mb-8 gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
              <Link href="/admin">
                <Button variant="ghost" size="sm" data-testid="button-back-admin" className="self-start">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Admin
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">
                  Staff Notes Manager
                </h1>
                <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 mt-1">
                  Track banked hours, tool costs, and general notes
                </p>
              </div>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button 
                onClick={generatePDF} 
                variant="outline"
                className="flex-1 sm:flex-none"
                data-testid="button-export-pdf"
              >
                <Download className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
              <Button 
                onClick={() => setIsAddStaffOpen(true)} 
                className="bg-blue-600 hover:bg-blue-700 flex-1 sm:flex-none"
                data-testid="button-add-staff"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Staff
              </Button>
            </div>
          </div>

          {/* Staff Grid */}
          <div className="grid gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {staff.map((member) => (
              <Card 
                key={member.id} 
                className="hover:shadow-lg transition-all duration-200 cursor-pointer border-2 hover:border-blue-200 dark:hover:border-blue-700"
                onClick={() => setSelectedStaff(member)}
              >
                <CardHeader className="pb-2 sm:pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base sm:text-lg font-semibold text-gray-900 dark:text-gray-100">
                      {member.name}
                    </CardTitle>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          generateIndividualPDF(member);
                        }}
                        className="text-blue-500 hover:text-blue-700 hover:bg-blue-50 p-1"
                        data-testid={`button-export-staff-pdf-${member.id}`}
                        title={`Export PDF for ${member.name}`}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteStaffMember(member.id);
                        }}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1"
                        data-testid={`button-delete-staff-${member.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-blue-600 flex-shrink-0" />
                      <span className="text-sm font-medium">
                        Banked: <span className="text-blue-600">{member.bankedHours} hrs</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-purple-600 flex-shrink-0" />
                      <span className="text-sm font-medium">
                        RDO: <span className="text-purple-600">{member.rdoHours} hrs</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-green-600 flex-shrink-0" />
                      <span className="text-sm font-medium">
                        Value: <span className="text-green-600">${(parseFloat(member.bankedHours) * parseFloat(member.hourlyRate)).toFixed(2)}</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-red-600 flex-shrink-0" />
                      <span className="text-sm font-medium">
                        Tools: <span className="text-red-600">${parseFloat(member.toolCostOwed).toFixed(2)}</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-600 flex-shrink-0" />
                      <span className="text-sm text-gray-600">
                        {member.notes.length} note{member.notes.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {staff.length === 0 && (
            <div className="text-center py-12 sm:py-16 px-4">
              <User className="h-12 w-12 sm:h-16 sm:w-16 text-gray-400 mx-auto mb-3 sm:mb-4" />
              <h3 className="text-lg sm:text-xl font-medium text-gray-900 dark:text-gray-100 mb-2">
                No staff members yet
              </h3>
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 mb-4 sm:mb-6">
                Add your first staff member to start tracking
              </p>
              <Button 
                onClick={() => setIsAddStaffOpen(true)}
                className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Staff Member
              </Button>
            </div>
          )}
        </div>

        {/* Add Staff Dialog */}
        <Dialog open={isAddStaffOpen} onOpenChange={setIsAddStaffOpen}>
          <DialogContent className="max-w-md mx-4 sm:mx-auto">
            <DialogHeader>
              <DialogTitle className="text-lg">Add Staff Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="staff-name" className="text-sm font-medium">Staff Member Name</Label>
                <Input
                  id="staff-name"
                  value={newStaffName}
                  onChange={(e) => setNewStaffName(e.target.value)}
                  placeholder="Enter full name"
                  data-testid="input-staff-name"
                  className="mt-1 h-11"
                />
              </div>
              <div>
                <Label htmlFor="staff-rate" className="text-sm font-medium">Hourly Rate ($)</Label>
                <Input
                  id="staff-rate"
                  type="number"
                  step="0.01"
                  value={newStaffRate}
                  onChange={(e) => setNewStaffRate(e.target.value)}
                  placeholder="45.00"
                  data-testid="input-staff-rate"
                  onKeyDown={(e) => e.key === 'Enter' && addStaffMember()}
                  className="mt-1 h-11"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddStaffOpen(false);
                    setNewStaffName('');
                    setNewStaffRate('');
                  }}
                  data-testid="button-cancel-staff"
                  className="flex-1 h-11"
                >
                  Cancel
                </Button>
                <Button onClick={addStaffMember} data-testid="button-save-staff" className="flex-1 h-11">
                  Add Staff
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Staff Rate Dialog */}
        <Dialog open={!!editingStaff} onOpenChange={() => { setEditingStaff(null); setEditStaffRate(''); }}>
          <DialogContent className="max-w-md mx-4 sm:mx-auto">
            <DialogHeader>
              <DialogTitle className="text-lg">Edit Hourly Rate - {editingStaff?.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-staff-rate" className="text-sm font-medium">Hourly Rate ($)</Label>
                <Input
                  id="edit-staff-rate"
                  type="number"
                  step="0.01"
                  value={editStaffRate}
                  onChange={(e) => setEditStaffRate(e.target.value)}
                  placeholder="45.00"
                  data-testid="input-edit-staff-rate"
                  onKeyDown={(e) => e.key === 'Enter' && updateStaffRate()}
                  className="mt-1 h-11"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setEditingStaff(null);
                    setEditStaffRate('');
                  }}
                  data-testid="button-cancel-edit-rate"
                  className="flex-1 h-11"
                >
                  Cancel
                </Button>
                <Button onClick={updateStaffRate} data-testid="button-save-edit-rate" className="flex-1 h-11">
                  Update Rate
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // Individual staff member view
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded-md shadow-lg z-50">
          {toastMessage}
        </div>
      )}

      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 sm:mb-6 gap-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
            <Button
              variant="ghost"
              onClick={() => setSelectedStaff(null)}
              data-testid="button-back-staff-list"
              className="self-start"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Staff List
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">
                {selectedStaff.name}
              </h1>
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">
                Staff member details and notes
              </p>
            </div>
          </div>
          <Button 
            onClick={() => setIsAddNoteOpen(true)}
            className="bg-green-600 hover:bg-green-700 w-full sm:w-auto"
            data-testid="button-add-note"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Note
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 mb-6 sm:mb-8">
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2 px-4 pt-3">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600" />
                <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-gray-100">Banked Hours</h3>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-3">
              <div className="text-xl sm:text-2xl font-bold text-blue-600">
                {selectedStaff.bankedHours}
              </div>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Overtime hours</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2 px-4 pt-3">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-purple-600" />
                <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-gray-100">RDO Hours</h3>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-3">
              <div className="text-xl sm:text-2xl font-bold text-purple-600">
                {selectedStaff.rdoHours}
              </div>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Rostered days off</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="pb-2 px-4 pt-3">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-green-600" />
                <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-gray-100">Hours Value</h3>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-3">
              <div className="text-xl sm:text-2xl font-bold text-green-600">
                ${(parseFloat(selectedStaff.bankedHours) * parseFloat(selectedStaff.hourlyRate)).toFixed(2)}
              </div>
              <div className="flex items-center justify-between">
                <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">@ ${parseFloat(selectedStaff.hourlyRate)}/hr</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => startEditStaffRate(selectedStaff)}
                  className="h-6 px-2 text-xs"
                  data-testid="button-edit-rate"
                >
                  <Edit3 className="h-3 w-3" />
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-red-500">
            <CardHeader className="pb-2 px-4 pt-3">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-red-600" />
                <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-gray-100">Tool Costs</h3>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-3">
              <div className="text-xl sm:text-2xl font-bold text-red-600">
                ${parseFloat(selectedStaff.toolCostOwed).toFixed(2)}
              </div>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Amount owed</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-gray-500">
            <CardHeader className="pb-2 px-4 pt-3">
              <div className="flex items-center gap-2">
                <Calculator className="h-4 w-4 sm:h-5 sm:w-5 text-gray-600" />
                <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-gray-100">Total Notes</h3>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-3">
              <div className="text-xl sm:text-2xl font-bold text-gray-700 dark:text-gray-300">
                {selectedStaff.notes.length}
              </div>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">All entries</p>
            </CardContent>
          </Card>
        </div>

        {/* Notes List */}
        <Card>
          <CardHeader>
            <CardTitle>Notes History</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedStaff.notes.length === 0 ? (
              <div className="text-center py-8 sm:py-12 px-4">
                <User className="h-10 w-10 sm:h-12 sm:w-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">
                  No notes yet. Add the first note to start tracking.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {selectedStaff.notes
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((note) => (
                    <div 
                      key={note.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between p-3 sm:p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors gap-3 sm:gap-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {getTypeIcon(note.type)}
                          <Badge className={`${getTypeBadgeColor(note.type)} text-xs`}>
                            {formatTypeName(note.type)}
                          </Badge>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm sm:text-base text-gray-900 dark:text-gray-100 break-words">
                            {note.description}
                          </p>
                          <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">
                            {format(new Date(note.date), 'MMM d, yyyy h:mm a')}
                          </p>
                        </div>
                        {parseFloat(note.amount) !== 0 && (
                          <div className="text-left sm:text-right flex-shrink-0">
                            <div className={`font-semibold text-sm sm:text-base ${
                              parseFloat(note.amount) > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {note.type === 'banked_hours' || note.type === 'rdo_hours'
                                ? `${parseFloat(note.amount) > 0 ? '+' : ''}${parseFloat(note.amount)} hrs`
                                : `${parseFloat(note.amount) > 0 ? '+' : ''}$${Math.abs(parseFloat(note.amount)).toFixed(2)}`
                              }
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 justify-end flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEditNote(note)}
                          data-testid={`button-edit-note-${note.id}`}
                          className="h-8 w-8 p-0"
                        >
                          <Edit3 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteNote(note.id)}
                          className="text-red-500 hover:text-red-700 h-8 w-8 p-0"
                          data-testid={`button-delete-note-${note.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add/Edit Note Dialog */}
      <Dialog open={isAddNoteOpen} onOpenChange={resetNoteForm}>
        <DialogContent className="max-w-md mx-4 sm:mx-auto max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">
              {editingNote ? 'Edit Note' : 'Add Note'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="note-type" className="text-sm font-medium">Note Type</Label>
              <Select 
                value={noteForm.type} 
                onValueChange={(value: 'banked_hours' | 'tool_cost' | 'rdo_hours' | 'general') => 
                  setNoteForm(prev => ({ ...prev, type: value }))
                }
              >
                <SelectTrigger data-testid="select-note-type" className="mt-1 h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="banked_hours">Banked Hours</SelectItem>
                  <SelectItem value="rdo_hours">RDO Hours</SelectItem>
                  <SelectItem value="tool_cost">Tool Cost</SelectItem>
                  <SelectItem value="general">General Note</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="note-description" className="text-sm font-medium">Description</Label>
              <Textarea
                id="note-description"
                value={noteForm.description}
                onChange={(e) => setNoteForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Enter note description..."
                rows={3}
                data-testid="textarea-description"
                className="mt-1 resize-none"
              />
            </div>

            <div>
              <Label htmlFor="note-amount" className="text-sm font-medium">
                {noteForm.type === 'banked_hours' || noteForm.type === 'rdo_hours' ? 'Hours (+/-)' : 'Amount (+/-)'}
              </Label>
              <Input
                id="note-amount"
                type="number"
                step={noteForm.type === 'banked_hours' || noteForm.type === 'rdo_hours' ? '0.25' : '0.01'}
                value={noteForm.amount}
                onChange={(e) => setNoteForm(prev => ({ ...prev, amount: e.target.value }))}
                placeholder={noteForm.type === 'banked_hours' || noteForm.type === 'rdo_hours' ? '8.0' : '50.00'}
                data-testid="input-amount"
                className="mt-1 h-11"
              />
              <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                Use positive numbers to add, negative to subtract
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                onClick={resetNoteForm}
                data-testid="button-cancel-note"
                className="flex-1 h-11"
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button 
                onClick={editingNote ? updateNote : addNote}
                className="bg-green-600 hover:bg-green-700 flex-1 h-11"
                data-testid="button-save-note"
              >
                <Save className="h-4 w-4 mr-2" />
                {editingNote ? 'Update' : 'Add'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}